package com.apple;

import java.io.IOException;
import java.util.*;
import java.util.stream.Collectors;

public class Main {

    public static void main(String[] args) throws IOException {
        Scanner myObj = new Scanner(System.in);
        System.out.println("Enter Number of Players (N): ");
        int numberOfPlayers = Integer.parseInt(myObj.nextLine());
        System.out.println("Enter Points to Accumulate (M): ");
        int maxPoints = Integer.parseInt(myObj.nextLine());
        diceGame(numberOfPlayers, maxPoints);
    }

    public static void diceGame(int n, int m) throws IOException {
        List<String> players = new ArrayList<>();
        Map<String, Player> playerMap = new HashMap<>();
        Scanner myObj = new Scanner(System.in);
        for(int i=0; i<n; i++) {
            String player_name = "Player-"+(i+1);
            players.add(player_name);
            playerMap.put(player_name, new Player());
        }

        Collections.shuffle(players);

        while(!players.isEmpty()) {
            for(Iterator<String> it = players.iterator();it.hasNext();) {
                String p = it.next();
                Player curr_player = playerMap.get(p);
                if(!curr_player.isSkip_turn()) {
                    System.out.println(p+" its your turn (press 'r' to roll the dice):");
                    char c = myObj.nextLine().charAt(0);
                    if(c == 'r') {
                        curr_player = rollDice(p, curr_player, playerMap);
                    } else {
                        System.out.println("Invalid option '"+c+"' to roll the dice");
                        break;
                    }

                    if(curr_player.getTotal_score() >= m) {
                        it.remove();
                        if (players.isEmpty()) {
                            break;
                        }
                    }

                    if(curr_player.getCurrent_score() == 6) {
                        curr_player = rollDice(p, curr_player, playerMap);
                    }
                } else {
                    curr_player.setSkip_turn(false);
                    curr_player.setCurrent_score(0);
                }
            }
        }

    }

    public static Player rollDice(String p, Player curr_player, Map<String, Player> playerMap) throws IOException {
        int dice_value = generateRandomDiceRollNumber();
        System.out.println("Current Dice score - "+ dice_value +"\n");
        curr_player.setTotal_score(curr_player.getTotal_score() + dice_value);
        if(dice_value == 1 && curr_player.getCurrent_score() == 1) {
            curr_player.setSkip_turn(true);
        }
        curr_player.setCurrent_score(dice_value);
        printScoreBoard(playerMap);
        return curr_player;
    }

    public static void printScoreBoard(Map<String, Player> playerMap) {
        System.out.println("***Scoreboard***");
        playerMap.entrySet().stream()
                .sorted(Map.Entry.comparingByValue((p1, p2) -> p2.getTotal_score() - p1.getTotal_score()))
                        .forEach(entry -> System.out.println(entry.getKey() + ": " + entry.getValue().getTotal_score()+"\n-------------"));
        System.out.println();
        //playerMap.forEach((k, v) -> System.out.println(k +" - "+v.getTotal_score()));
        System.out.println("***Scoreboard***\n");
    }

    static int generateRandomDiceRollNumber() {
        Random rand = new Random();
        return rand.nextInt(5)+1;
    }

    public static class Player {
        public int total_score;
        public int current_score;
        public boolean skip_turn;

        public int getTotal_score() {
            return total_score;
        }

        public void setTotal_score(int total_score) {
            this.total_score = total_score;
        }

        public int getCurrent_score() {
            return current_score;
        }

        public void setCurrent_score(int current_score) {
            this.current_score = current_score;
        }

        public boolean isSkip_turn() {
            return skip_turn;
        }

        public void setSkip_turn(boolean skip_turn) {
            this.skip_turn = skip_turn;
        }
    }
}
